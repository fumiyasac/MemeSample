//
//  MMDataViewController.swift
//  MEMELib_Swift
//
//  Created by 堀 宏行 on 2016/10/26.
//  Copyright © 2016年 JIN CO.,LTD. All rights reserved.
//

import UIKit
class MMDataViewController : UIViewController, UITableViewDataSource, UITableViewDelegate
{
    var indicatorView : UIView!
    var dateFormatter : DateFormatter!
    var latestRealTimeData : MEMERealTimeData?
    @IBOutlet weak var dataTableView: UITableView!
    
    override func viewDidLoad() {
        self.indicatorView = UIView.init(frame: CGRect(x: 0, y: 0, width: 24, height: 24))
        self.indicatorView.alpha = 0.20
        self.indicatorView.backgroundColor = UIColor.white
        self.indicatorView.layer.cornerRadius = self.indicatorView.frame.size.height * 0.5
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(customView: self.indicatorView)
        self.navigationItem.leftBarButtonItem = UIBarButtonItem.init(title: "Disconnect", style: UIBarButtonItemStyle.plain, target: self, action: #selector(MMDataViewController.disconnectButtonPressed(_:)))
        
        dateFormatter = DateFormatter.init()
        dateFormatter.locale = NSLocale.current
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .short

    }
    
    func disconnectButtonPressed( _ sender:AnyObject )
    {
        let status : MEMEStatus = MEMELib.sharedInstance().disconnectPeripheral();
        checkMEMEStatus(status: status)
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 16
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: "DataCellIdentifier", for: indexPath)
        
        var label : String = ""
        var value : String = ""
        
        
        if let data : MEMERealTimeData = self.latestRealTimeData
        {
         
            switch indexPath.row {
            case 0:
                label = "Fit Status"
                value = data.fitError.description
            case 1:
                label = "Walking";
                value = data.isWalking.description
                break;
                
            case 2:
                label = "NoiseStatus";
                value = data.noiseStatus.description
                break;
                
            case 3:
                label = "Power Left";
                value = data.powerLeft.description
                break;
                
            case 4:
                label = "Eye Move Up";
                value = data.eyeMoveUp.description
                break;
                
            case 5:
                label = "Eye Move Down";
                value = data.eyeMoveDown.description
                break;
                
            case 6:
                label = "Eye Move Left";
                value = data.eyeMoveLeft.description
                break;
                
            case 7:
                label = "Eye Move Right";
                value = data.eyeMoveRight.description
                break;
                
            case 8:
                label = "Blink Streangth";
                value = data.blinkStrength.description
                break;
                
            case 9:
                label = "Blink Speed";
                value = data.blinkSpeed.description
                break;
                
            case 10:
                label = "Roll";
                value = data.roll.description
                break;
                
            case 11:
                label = "Pitch";
                value = data.pitch.description
                break;
                
            case 12:
                label = "Yaw";
                value = data.yaw.description
                break;
                
            case 13:
                label = "Acc X";
                value = data.accX.description
                break;
                
            case 14:
                label = "Acc Y";
                value = data.accY.description
                break;
                
            case 15:
                label = "Acc Z";
                value = data.accZ.description
                break;
                
            default:
                break;
              
            }
        }
        cell?.textLabel?.text = label
        cell?.detailTextLabel?.text = value
        return cell!
    }
    
    @IBAction func startDataReportButtonPressed(_ sender: AnyObject) {
        let status : MEMEStatus = MEMELib.sharedInstance().startDataReport();
        checkMEMEStatus(status: status)
    }
    @IBAction func stopDataReportButtonPressed(_ sender: AnyObject) {
        let status : MEMEStatus = MEMELib.sharedInstance().stopDataReport();
        checkMEMEStatus(status: status)
    }
    
    func memeRealTimeModeDataReceived(_ data : MEMERealTimeData)
    {
        self.latestRealTimeData = data
        self.blinkIndicator()
        self.dataTableView.reloadData()
    }
    
    func blinkIndicator()
    {
        UIView.animate(withDuration: 0.05, animations: {
            self.indicatorView.backgroundColor = UIColor.red
            }, completion: { finished in
            self.indicatorView.backgroundColor = UIColor.white
            })
    }
    
    func checkMEMEStatus( status : MEMEStatus )
    {
        if ( status == MEME_ERROR_APP_AUTH)
        {
            let alert : UIAlertController = UIAlertController(title: "App Auth Failed", message: "Invalid Application ID or Client Secret", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default){ action in
                
            })
            present(alert, animated: true, completion: nil)
        }
        else if ( status == MEME_ERROR_SDK_AUTH )
        {
            let alert : UIAlertController = UIAlertController(title: "SDK Auth Failed", message: "Invalid SDK. Please update to the latest SDK.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default){ action in
                
            })
            present(alert, animated: true, completion: nil)
        }
        else if ( status == MEME_OK )
        {
            print("Status: MEME_OK")
        }
    }
}
