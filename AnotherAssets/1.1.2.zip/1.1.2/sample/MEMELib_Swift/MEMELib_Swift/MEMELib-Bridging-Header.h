//
//  MEMELib-Bridging-Header.h
//  MEMELib_Swift
//
//  Copyright © 2016年 JIN CO.,LTD. All rights reserved.
//

#ifndef MEMELib_Bridging_Header_h
#define MEMELib_Bridging_Header_h

#import <MEMELib/MEMELib.h>

#endif /* MEMELib_Bridging_Header_h */
