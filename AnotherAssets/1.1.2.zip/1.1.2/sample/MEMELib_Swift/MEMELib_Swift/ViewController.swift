//
//  ViewController.swift
//  MEMELib_Swift
//
//  Copyright © 2016年 JIN CO.,LTD. All rights reserved.
//

import UIKit

class ViewController: UITableViewController, MEMELibDelegate  {

    var peripheralFound : NSMutableArray = [];
    var dataViewCtl : MMDataViewController?;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.isUserInteractionEnabled = true;
        MEMELib.sharedInstance().addObserver(self, forKeyPath: "centralManagerEnabled", options: NSKeyValueObservingOptions.new, context: nil)
        
        self.title = "JINS MEME Demo"
        self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(title: "Scan", style: UIBarButtonItemStyle.plain, target: self, action: #selector(ViewController.scanButtonPressed(sender:)))
        self.navigationItem.rightBarButtonItem?.isEnabled = false;
    }

    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        
        if ( keyPath == "centralManagerEnabled")
        {
            MEMELib.sharedInstance().setAutoConnect(false)
            MEMELib.sharedInstance().delegate = self
            self.navigationItem.rightBarButtonItem?.isEnabled = true;
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    internal func scanButtonPressed(sender : UIButton)
    {
        let status:MEMEStatus = MEMELib.sharedInstance().startScanningPeripherals()
        checkMEMEStatus(status: status)
    }

    //jins meme delegate
    func memePeripheralFound(_ peripheral: CBPeripheral!, withDeviceAddress address: String!) {
        print("peripheral found \(peripheral.identifier.uuidString)")
        self.peripheralFound.add(peripheral)
        tableView.reloadData()
    }
    
    func memeAppAuthorized(_ status: MEMEStatus) {
        checkMEMEStatus(status: status)
    }
    
    func memePeripheralConnected(_ peripheral: CBPeripheral!) {
        print("JINS MEME connected")
        self.navigationItem.rightBarButtonItem?.isEnabled = false;
        self.tableView.isUserInteractionEnabled = false;
        performSegue(withIdentifier: "DataViewSegue", sender: self)
    }
    
    func memePeripheralDisconnected(_ peripheral: CBPeripheral!) {
        
        self.navigationItem.rightBarButtonItem?.isEnabled = true;
        self.tableView.isUserInteractionEnabled = true;
        self.dismiss(animated: true, completion: {
            print("JINS MEME Disconnected")
        })
    }
    
    func memeRealTimeModeDataReceived(_ data: MEMERealTimeData!) {
        if ( self.dataViewCtl != nil)
        {
            self.dataViewCtl?.memeRealTimeModeDataReceived(data)
        }
    }
    
    //table
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.peripheralFound.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell : UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: "DeviceListCellIdentifier")
        if ( cell == nil )
        {
            cell = UITableViewCell.init(style: UITableViewCellStyle.default, reuseIdentifier: "DeviceListCellIdentifier")
        }
        let peripheral : CBPeripheral = self.peripheralFound.object(at: indexPath.row) as! CBPeripheral
        cell?.textLabel?.text = peripheral.identifier.uuidString
        return cell!
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let peripheral : CBPeripheral = self.peripheralFound.object(at: indexPath.row) as! CBPeripheral
        let status : MEMEStatus = MEMELib.sharedInstance().connect(peripheral)
        checkMEMEStatus(status: status)
        print("Start connecting to JINS MEME")
    }
    
    //transtion
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "DataViewSegue")
        {
            let naviCtl : UINavigationController = segue.destination as! UINavigationController
            self.dataViewCtl = naviCtl.topViewController as! MMDataViewController?
        }
    }
   
    func checkMEMEStatus( status : MEMEStatus )
    {
        if ( status == MEME_ERROR_APP_AUTH)
        {
            let alert : UIAlertController = UIAlertController(title: "App Auth Failed", message: "Invalid Application ID or Client Secret", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default){ action in
                
            })
            present(alert, animated: true, completion: nil)
        }
        else if ( status == MEME_ERROR_SDK_AUTH )
        {
            let alert : UIAlertController = UIAlertController(title: "SDK Auth Failed", message: "Invalid SDK. Please update to the latest SDK.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default){ action in
                
            })
            present(alert, animated: true, completion: nil)
        }
        else if ( status == MEME_OK )
        {
            print("Status: MEME_OK")
        }
    }
    
}

