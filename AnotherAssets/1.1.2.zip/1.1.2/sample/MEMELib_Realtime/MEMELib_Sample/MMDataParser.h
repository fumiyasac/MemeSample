//
//  MMDataParser.h
//  MEME_Test
//
//  Created by Nao Tokui on 10/10/14.
//  Copyright (c) 2014 Nao Tokui. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MMDataParser : NSObject

@end
