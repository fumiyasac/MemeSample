//
//  MMViewController.m
//  
//
//  Created by JINS MEME on 8/11/14.
//  Copyright (c) 2014 JIN. All rights reserved.
//

#import "MMViewController.h"
#import <MEMELib/MEMELib.h>

@interface MMViewController ()

@property (nonatomic, strong) NSMutableArray *peripheralsFound;

@end

@implementation MMViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // add Notifications
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(memeAppAuthorized:) name: MEMELibAppAuthorizedNotification object: nil];
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(memePeripheralFound:) name: MEMELibPeripheralFoundNotification object: nil];
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(memePeripheralConnected:) name: MEMELibPeripheralConnectedNotification object: nil];
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(memePeripheralDisconnected:) name: MEMELibPeripheralDisconnetedNotification object: nil];
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(memeRealTimeModeDataReceived:) name: MEMELibRealtimeModeDataReceivedNotification object: nil];
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(notificationReceived:) name: MEMELibCommandResponseNotification object: nil];
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(notificationReceived:) name: MEMELibDeviceInfoUpdatedNotification object: nil];
    [[MEMELib sharedInstance] addObserver: self forKeyPath: @"centralManagerEnabled" options: NSKeyValueObservingOptionNew context:nil];
    
    
    
    self.peripheralsFound = @[].mutableCopy;
    
    self.title      = @"MEME Demo";
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle: @"Scan" style:UIBarButtonItemStylePlain target: self action:@selector(scanButtonPressed:)];
    self.navigationItem.rightBarButtonItem.enabled = NO;
}

- (void) observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    if ([keyPath isEqualToString: @"centralManagerEnabled"]){
        self.navigationItem.rightBarButtonItem.enabled = YES;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)scanButtonPressed:(id)sender {
    // Start Scanning
    MEMEStatus status = [[MEMELib sharedInstance] startScanningPeripherals];
    [self checkMEMEStatus: status];
}

#pragma mark
#pragma mark MEMELib Notifications

// for Notification of CommandResponse and DeviceInfoUndated
- (void) notificationReceived: (NSNotification *) notification
{
    if ( notification.name == MEMELibCommandResponseNotification)
    {
        int resCode = (int)[notification.userInfo[MEMELibResponseEventCodeUserInfoKey] integerValue];
        bool result = [notification.userInfo[MEMELibResponseCommandResultUserInfoKey] boolValue];
        NSLog(@"response code %d, result %d", resCode, result);
    }
    NSLog(@"%@ %@", notification.name, notification.userInfo.description);
    
}

// for Notification of JINS MEME Found
- (void) memePeripheralFound: (NSNotification *) notification
{
    NSDictionary *userInfo = (NSDictionary *)[notification userInfo];
    CBPeripheral *peripheral = userInfo[MEMELibPeripheralUserInfoKey];
    [self.peripheralsFound addObject: peripheral];
    NSLog(@"peripheral found %@", [peripheral.identifier UUIDString]);
    [self.tableView reloadData];
}

// for Notification of JINS MEME Connected
- (void) memePeripheralConnected: (NSNotification *) notification
{
    NSDictionary *userInfo = (NSDictionary *)[notification userInfo];
    CBPeripheral *peripheral = userInfo[MEMELibPeripheralUserInfoKey];
    NSLog(@"MEME Device Connected! %@", [peripheral.identifier UUIDString]);
    self.navigationItem.rightBarButtonItem.enabled         = NO;
    self.tableView.userInteractionEnabled = NO;
    [self performSegueWithIdentifier:@"DataViewSegue" sender: self];
    
}

// for Notification of JINS MEME Disconnected
- (void) memePeripheralDisconnected: (NSNotification *) notification
{
    NSDictionary *userInfo = (NSDictionary *)[notification userInfo];
    CBPeripheral *peripheral = userInfo[MEMELibPeripheralUserInfoKey];
    self.navigationItem.rightBarButtonItem.enabled       = YES;
    self.tableView.userInteractionEnabled = YES;
    
    [self dismissViewControllerAnimated: YES completion: ^{
        self.dataViewCtl = nil;
        NSLog(@"MEME Device Disconnected! %@", [peripheral.identifier UUIDString]);

    }];
}

// for Notification of RealtimeData received
- (void) memeRealTimeModeDataReceived: (NSNotification *) notification
{
    NSDictionary *userInfo = (NSDictionary *)[notification userInfo];
    MEMERealTimeData *data = userInfo[MEMELibRealtimeDataUserInfoKey];
    
    if (self.dataViewCtl) [self.dataViewCtl memeRealTimeModeDataReceived: data];
}

// for Notification of Application Authorization
- (void) memeAppAuthorized:(NSNotification *) notification
{
    NSDictionary *userInfo = (NSDictionary *)[notification userInfo];
    MEMEStatus status = [userInfo[MEMELibStatusCodeUserInfoKey] intValue];
    
    [self checkMEMEStatus: status];
}

#pragma mark
#pragma mark Peripheral List

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.peripheralsFound count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier: @"DeviceListCellIdentifier"];
    if (!cell){
        cell = [[UITableViewCell alloc] initWithStyle: UITableViewCellStyleDefault reuseIdentifier: @"DeviceListCellIdentifier"];
    }
    
    CBPeripheral *peripheral = [self.peripheralsFound objectAtIndex: indexPath.row];
    cell.textLabel.text = [peripheral.identifier UUIDString];
    
    return cell;
}

- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
     CBPeripheral *peripheral = [self.peripheralsFound objectAtIndex: indexPath.row];
     MEMEStatus status = [[MEMELib sharedInstance] connectPeripheral: peripheral ];
    [self checkMEMEStatus: status];
    
    NSLog(@"Start connecting to MEME Device...");
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString: @"DataViewSegue"]){
        UINavigationController *naviCtl = segue.destinationViewController;
        self.dataViewCtl                = (MMDataViewController *)naviCtl.topViewController;
    }
}

#pragma mark UTILITY

- (void) checkMEMEStatus: (MEMEStatus) status
{
    if (status == MEME_ERROR_APP_AUTH){
        [[[UIAlertView alloc] initWithTitle: @"App Auth Failed" message: @"Invalid Application ID or Client Secret " delegate: nil cancelButtonTitle: nil otherButtonTitles: @"OK", nil] show];
    } else if (status == MEME_ERROR_SDK_AUTH){
        [[[UIAlertView alloc] initWithTitle: @"SDK Auth Failed" message: @"Invalid SDK. Please update to the latest SDK." delegate: nil cancelButtonTitle: nil otherButtonTitles: @"OK", nil] show];
    } else if (status == MEME_OK){
        NSLog(@"Status: MEME_OK");
    }
}



@end
